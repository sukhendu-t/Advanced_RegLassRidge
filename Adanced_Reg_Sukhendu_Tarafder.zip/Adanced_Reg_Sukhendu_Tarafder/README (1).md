# Project Name
> Identification of Attributes that predict the House Price


## Table of Contents
* [General Info](#general-information)
* [Technologies Used](#technologies-used)
* [Conclusions](#conclusions)
* [Acknowledgements](#acknowledgements)

<!-- You can include any other section that is pertinent to your problem -->

## General Information
- A US-based housing company named Surprise Housing has decided to enter the Australian market. The company uses data analytics to purchase houses at a price below their actual values and flip them on at a higher price. For the same purpose, the company has collected a data set from the sale of houses in Australia. The data is provided in the CSV file below. 

The company is looking at prospective properties to buy to enter the market. You are required to build a regression model using regularisation in order to predict the actual value of the prospective properties and decide whether to invest in them or not.
- 
- Which variables are significant in predicting the price of a house
- How well those variables describe the price of a house.

Create a model for price of houses with the available independent variables. This model will then be used by the management to understand how exactly the prices vary with the variables. They can accordingly manipulate the strategy of the firm and concentrate on areas that will yield high returns. Further, the model will be a good way for management to understand the pricing dynamics of a new market.

<!-- You don't have to answer all the questions - just the ones relevant to your project. -->

## Conclusions
- For Ridge Regression:
Train Score

As the alpha (lambda) increases, the r2 score decreases. That means the error increases. Because the model becomes less overfitting and more generalised. Thus by increasing the alpha the model becomes more simple.

Test Score

With the very lower value of alpha, the error is high as we can see the r2 value decreased. But the error for the train set is low. It means that the model is clearly overfitting with very low value of alpha. With the increasing value of alpha, the error started decreasing more and it reached to a peak at alph=2. Here, the error is least and accuracy (r2 score) is the highest. After alpha=2, the r2 score started decreasing as the alpha is increasing. Hence, the model accuracy started dipping. We need to pick the value of aplha for which the test score peaks up. In this case in alpha=2, the error is least in the test set and hence the accuracy is more approximately 84%.

So, the optimum alpha will be 2, for which we will have a right balance between the error and the generalisation of the model for creting a simpler model.

Ridge regression with optimal alpha = 2
- For Lasso Regression: 
Analysis of the  graph in the Note book, we can see that with very lower value of alpha (almost colse to 0) the accuracy of the train and test set is the highest. Coincidentally they both are alomost same.

Train Score

As the alpha (lambda) increases, the r2 score decreases. That means the error increases. Because the model becomes less overfitting and more generalised. At 0.002 (close to 0) the train set accury is highest(more than 80%). Test Score

At alpha = 0.002 the test accuracy is highest (more than 80%). After alpha=0.002, the r2 score started decreasing as the alpha is increasing. Hence, the model accuracy started dipping. We need to pick the value of aplha for which the test score peaks up. In this case at alpha=0.002, the error is least in the test set and hence the accuracy is more approximately 80%.

So, the optimum alpha will be 0.002, for which we will have a right balance between the error and the generalisation of the model for creating a simpler model.
- Top variables are:
  Params	      Coef
0	constant	0.162
10	GrLivArea	0.148
63	BsmtQual_Ex	0.076
17	GarageArea	0.045
66	BsmtExposure_Gd	0.028
71	BsmtFinType1_GLQ	0.021


<!-- You don't have to answer all the questions - just the ones relevant to your project. -->


## Technologies Used
- library - Pandas
- library - NumPy
- library - SKLearn

<!-- As the libraries versions keep on changing, it is recommended to mention the version of library used in this project -->

## Acknowledgements
Give credit here.
- This project was inspired by...
- References if any...
- This project was based on [this tutorial](https://www.example.com).


## Contact
Created by [@githubusername] - feel free to contact me!


<!-- Optional -->
<!-- ## License -->
<!-- This project is open source and available under the [... License](). -->

<!-- You don't have to include all sections - just the one's relevant to your project -->